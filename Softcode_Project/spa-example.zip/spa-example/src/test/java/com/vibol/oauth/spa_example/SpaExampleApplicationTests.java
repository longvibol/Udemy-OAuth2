package com.vibol.oauth.spa_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
